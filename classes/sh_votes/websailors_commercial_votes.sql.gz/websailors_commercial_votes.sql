-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Jeu 13 Août 2009 à 11:18
-- Version du serveur: 5.0.75
-- Version de PHP: 5.2.6-3ubuntu4.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `websailors_commercial`
--

-- --------------------------------------------------------

--
-- Structure de la table `votes`
--

CREATE TABLE IF NOT EXISTS `votes` (
  `type` varchar(30) collate utf8_bin NOT NULL default 'global',
  `id` int(11) NOT NULL,
  `ip` varchar(30) collate utf8_bin NOT NULL,
  `vote` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Contenu de la table `votes`
--

INSERT INTO `votes` (`type`, `id`, `ip`, `vote`) VALUES
('books', 4, '132.133.135.138', 9),
('books', 2, '127.0.0.1', 6),
('books', 4, '127.0.0.1', 9),
('books', 3, '127.0.0.1', 6),
('shop_products', 28, '127.0.0.1', 8),
('shop_products', 23, '127.0.0.1', 9);

-- --------------------------------------------------------

--
-- Structure de la table `votes_counts`
--

CREATE TABLE IF NOT EXISTS `votes_counts` (
  `type` varchar(30) collate utf8_bin NOT NULL default 'global',
  `id` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `vote` tinyint(4) NOT NULL,
  PRIMARY KEY  (`type`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Contenu de la table `votes_counts`
--

INSERT INTO `votes_counts` (`type`, `id`, `count`, `vote`) VALUES
('books', 4, 2, 9),
('sdgf', 12, 5, 5),
('books', 2, 1, 6),
('books', 3, 1, 6),
('shop_produ', 28, 0, 5),
('shop_products', 28, 1, 8),
('shop_products', 23, 1, 9);

-- --------------------------------------------------------

--
-- Structure de la table `votes_reader`
--

CREATE TABLE IF NOT EXISTS `votes_reader` (
  `searchType` varchar(50) collate utf8_bin NOT NULL,
  `table` varchar(50) collate utf8_bin NOT NULL,
  `idKey` varchar(50) collate utf8_bin NOT NULL,
  `searchedKey` varchar(100) collate utf8_bin NOT NULL,
  PRIMARY KEY  (`searchType`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Contenu de la table `votes_reader`
--

INSERT INTO `votes_reader` (`searchType`, `table`, `idKey`, `searchedKey`) VALUES
('bookNote', 'books', 'id', 'note');
